#!/usr/bin/env node
/**
 * Génère un fichier twa-manifest.json valide pour Bubblewrap,
 * à partir des arguments en ligne de commande envoyés par le workflow
 * GitHub Actions (eux-mêmes envoyés par le site NPS.PWA Studio).
 *
 * Usage :
 *   node generate-manifest.js --name "MonApp" --packageId "com.nps.monapp" \
 *     --url "https://exemple.com" --output "./twa-manifest.json"
 */

const fs = require('fs');
const path = require('path');

function parseArgs(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i].startsWith('--')) {
      const key = argv[i].slice(2);
      const value = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : '';
      args[key] = value;
      i++;
    }
  }
  return args;
}

const args = parseArgs(process.argv.slice(2));

const name = args.name || 'MonApp';
const packageId = args.packageId || 'com.nps.monapp';
const url = (args.url || '').replace(/\/$/, '');
const themeColor = args.themeColor || '#7c6eff';
const backgroundColor = args.backgroundColor || '#0a0a14';
const appVersionName = args.appVersionName || '1.0.0';
const minSdkVersion = parseInt(args.minSdkVersion || '23', 10);
const outputPath = args.output || './twa-manifest.json';

const permissions = (args.permissions || '')
  .split(',')
  .map((p) => p.trim())
  .filter(Boolean);

if (!url) {
  console.error('✗ Erreur : --url est requis (URL HTTPS de la PWA).');
  process.exit(1);
}

let host;
try {
  host = new URL(url).hostname;
} catch (e) {
  console.error(`✗ Erreur : URL invalide "${url}"`);
  process.exit(1);
}

const manifest = {
  packageId,
  host,
  name,
  launcherName: name.substring(0, 12),
  display: 'standalone',
  themeColor,
  navigationColor: themeColor,
  navigationColorDark: backgroundColor,
  navigationDividerColor: themeColor,
  navigationDividerColorDark: backgroundColor,
  backgroundColor,
  enableNotifications: permissions.includes('android.permission.POST_NOTIFICATIONS'),
  startUrl: '/',
  iconUrl: `${url}/icon-512.png`,
  maskableIconUrl: `${url}/icon-512.png`,
  splashScreenFadeOutDuration: 300,
  signingKey: {
    path: './android.keystore',
    alias: 'nps-key',
  },
  appVersionName,
  appVersionCode: 1,
  shortcuts: [],
  generatorApp: 'nps-pwa-studio',
  minSdkVersion,
  // Bubblewrap n'a pas de champ natif "permissions" — elles sont injectées
  // par le post-traitement ci-dessous dans AndroidManifest.xml si besoin.
  fallbackType: 'customtabs',
};

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, JSON.stringify(manifest, null, 2));

console.log(`✓ twa-manifest.json généré → ${outputPath}`);
console.log(`  App: ${name} (${packageId})`);
console.log(`  Host: ${host}`);
if (permissions.length) {
  console.log(`  Permissions demandées: ${permissions.join(', ')}`);
  console.log('  ⚠ Note: Bubblewrap gère nativement peu de permissions hors notifications/');
  console.log('    géolocalisation (déléguées au système). Caméra/micro/stockage nécessitent');
  console.log('    une intégration WebView native plus poussée que le TWA standard.');
}
